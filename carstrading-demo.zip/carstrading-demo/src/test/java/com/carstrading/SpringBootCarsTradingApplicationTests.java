package com.carstrading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCarsTradingApplicationTests {

	@Test
	void contextLoads() {
	}

}
