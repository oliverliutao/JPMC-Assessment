package com.carstrading.models.entity;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
@Table(name = "car")
public class Car implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank
    @Column(name = "MAKE", length = 20)
    private String make;

    @NotBlank
    @Column(name = "MODEL", length = 20)
    private String model;

    @Column(name = "SOLD_INDICATOR")
    private boolean soldIndicator = false;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="user_id")
    private User user;

    public Car() {}

    public Car(String make, String model, boolean soldIndicator) {
        this.make = make;
        this.model = model;
        this.soldIndicator = soldIndicator;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public User getUser() { return this.user; };

    public void setUser(User user) { this.user = user; }

    public boolean getSoldIndicator() { return this.soldIndicator; }

    public void setSoldIndicator(boolean soldIndicator) { this.soldIndicator = soldIndicator; }
}
