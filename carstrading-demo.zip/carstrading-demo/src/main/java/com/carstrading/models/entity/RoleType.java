package com.carstrading.models.entity;

public enum RoleType {
  ROLE_BUYER,
  ROLE_ADMIN
}
