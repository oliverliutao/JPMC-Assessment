package com.carstrading.models.payload.request;

import javax.validation.constraints.NotBlank;

public class CarRequest {
    @NotBlank
    private String make;

    @NotBlank
    private String model;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
