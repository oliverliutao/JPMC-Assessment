package com.carstrading.repository;

import java.util.Optional;

import com.carstrading.models.entity.Role;
import com.carstrading.models.entity.RoleType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
  Optional<Role> findByName(RoleType name);
}
