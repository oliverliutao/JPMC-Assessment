package com.carstrading.services;

import com.carstrading.models.payload.request.LoginRequest;

public interface AuthService {
    UserDetailsImpl signin(LoginRequest loginRequest);
}
