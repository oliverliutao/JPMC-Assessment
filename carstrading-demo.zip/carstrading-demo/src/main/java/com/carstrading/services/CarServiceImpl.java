package com.carstrading.services;


import com.carstrading.repository.CarRepository;
import com.carstrading.exception.CarNotFoundException;
import com.carstrading.models.entity.Car;
import com.carstrading.models.entity.User;
import com.carstrading.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {
    private static final Logger logger = LoggerFactory.getLogger(CarServiceImpl.class);

    @Autowired
    CarRepository carRepository;

    @Autowired
    UserRepository userRepository;

    @Override
    public List<Car> findAll(String username) {
        List<Car> list = carRepository.findAll();
        return list.stream().filter(car -> (car.getUser() == null) || car.getUser().getUsername().equalsIgnoreCase(username)).collect(Collectors.toList());
    }

    public Car save(Car car) {
       return carRepository.save(car);
    }

    @Override
    public void delete(long id) throws  CarNotFoundException {
        Car car = carRepository.findById(id)
                .orElseThrow(() -> new CarNotFoundException("Car with id = " + id + " not found!"));
        carRepository.delete(car);
    }

    @Override
    public Car update(long id, String username) throws UsernameNotFoundException, CarNotFoundException, RuntimeException{

        Car car = carRepository.findById(id)
                .orElseThrow(() -> new CarNotFoundException("Car with id = " + id + " not found!"));
        
        if (car.getUser() != null) {
            throw new RuntimeException("");
        }

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + username));
        car.setUser(user);
        car.setSoldIndicator(true);
        return carRepository.save(car);
    }
}
