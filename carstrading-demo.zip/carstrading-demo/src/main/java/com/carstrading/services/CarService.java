package com.carstrading.services;

import com.carstrading.models.entity.Car;
import java.util.List;

public interface CarService {

    List<Car> findAll(String username);

    void delete(long id);

    Car update(long id, String username);
}
