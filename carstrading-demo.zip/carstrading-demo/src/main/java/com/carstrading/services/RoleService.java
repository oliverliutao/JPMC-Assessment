package com.carstrading.services;

import com.carstrading.models.entity.Role;
import com.carstrading.models.entity.RoleType;

public interface RoleService {

    Role findByName(RoleType roleType);
}
