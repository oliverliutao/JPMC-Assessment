package com.carstrading.services;

import com.carstrading.models.entity.User;

public interface UserService {

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);

    void save(User user);
}
