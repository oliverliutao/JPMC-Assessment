package com.carstrading.services;

import com.carstrading.exception.RoleNotFoundException;
import com.carstrading.models.entity.Role;
import com.carstrading.repository.RoleRepository;
import com.carstrading.models.entity.RoleType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    RoleRepository roleRepository;


    @Override
    public Role findByName(RoleType roleType) throws RoleNotFoundException {
        Role role = roleRepository.findByName(roleType)
                .orElseThrow(() -> new RuntimeException("Role " + roleType + " not found!"));
        return role;
    }
}
