package com.carstrading.controllers;

import com.carstrading.models.payload.request.CarRequest;
import com.carstrading.exception.CarNotFoundException;
import com.carstrading.models.entity.Car;
import com.carstrading.models.payload.response.MessageResponse;
import com.carstrading.security.jwtUtils.AuthUtils;
import com.carstrading.services.CarServiceImpl;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/cars")
@SecurityRequirement(name = "carstrading")
public class CarsController {

    private static final Logger logger = LoggerFactory.getLogger(CarsController.class);

    @Autowired
    CarServiceImpl carService;

    @Autowired
    private AuthUtils jwtUtils;

    @PreAuthorize("hasRole('BUYER') or hasRole('ADMIN')")
    @GetMapping("/v1")
    public ResponseEntity<List<Car>> getCars() throws CarNotFoundException {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
        String username = userDetails.getUsername();
        return ResponseEntity.ok().body(carService.findAll(username));
    }

    @PreAuthorize("hasRole('BUYER') or hasRole('ADMIN')")
    @PutMapping("/v1/{id}")
    public ResponseEntity<Car> buyCar(@PathVariable("id") int id) throws CarNotFoundException, UsernameNotFoundException, RuntimeException {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
        String username = userDetails.getUsername();
        return ResponseEntity.ok().body(carService.update(id, username));
    }


    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/v1")
    public ResponseEntity<Car> addCar(@RequestBody CarRequest car) {
        try {
            Car created = carService
                    .save(new Car(car.getMake(), car.getModel(), false));
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/v1/{id}")
    public ResponseEntity<MessageResponse> deleteCar(@PathVariable("id") long id) throws CarNotFoundException {
        carService.delete(id);
        return ResponseEntity.ok().body(new MessageResponse("Delete car successfully"));
    }

}

