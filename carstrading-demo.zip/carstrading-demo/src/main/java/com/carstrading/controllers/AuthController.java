package com.carstrading.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import com.carstrading.models.entity.Role;
import com.carstrading.models.payload.request.LoginRequest;
import com.carstrading.models.payload.request.SignupRequest;
import com.carstrading.models.payload.response.UserResponse;
import com.carstrading.services.AuthService;
import com.carstrading.exception.RoleNotFoundException;
import com.carstrading.models.entity.RoleType;
import com.carstrading.services.RoleService;
import com.carstrading.services.UserService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.carstrading.models.entity.User;
import com.carstrading.models.payload.response.MessageResponse;
import com.carstrading.security.jwtUtils.AuthUtils;
import com.carstrading.services.UserDetailsImpl;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
@SecurityRequirement(name = "carstrading")
public class AuthController {
  private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

  @Autowired
  AuthService authService;

  @Autowired
  UserService userService;

  @Autowired
  RoleService roleService;

  @Autowired
  PasswordEncoder encoder;

  @Autowired
  AuthUtils jwtUtils;

  @PostMapping("/v1/signin")
  public ResponseEntity<UserResponse> signin(@Valid @RequestBody LoginRequest loginRequest) {

    UserDetailsImpl userDetails = authService.signin(loginRequest);
    ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
    List<String> roles = userDetails.getAuthorities().stream()
        .map(item -> item.getAuthority())
        .collect(Collectors.toList());
    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
        .body(new UserResponse(userDetails.getId(),
                                   userDetails.getUsername(),
                                   userDetails.getEmail(),
                                   roles.get(0)));
  }

  @PostMapping("/v1/signup")
  public ResponseEntity<MessageResponse> registerUser(@Valid @RequestBody SignupRequest signUpRequest) throws RoleNotFoundException {

    if (userService.existsByUsername(signUpRequest.getUsername())) {
      return ResponseEntity.badRequest().body(new MessageResponse("Error: Username exists already"));
    }

    if (userService.existsByEmail(signUpRequest.getEmail())) {
      return ResponseEntity.badRequest().body(new MessageResponse("Error: Email exists already"));
    }

    User user = new User(signUpRequest.getUsername(),
                         signUpRequest.getEmail(),
                         encoder.encode(signUpRequest.getPassword()));

    String strRole = signUpRequest.getRole();
    Role role;

    if (strRole == null) {
      Role buyerRole = roleService.findByName(RoleType.ROLE_BUYER);
      role = buyerRole;
    } else {

      switch (strRole.toLowerCase()) {
      case "admin":
        Role adminRole = roleService.findByName(RoleType.ROLE_ADMIN);
        role = adminRole;
        break;
      default:
          Role buyerRole = roleService.findByName(RoleType.ROLE_BUYER);
          role = buyerRole;
      }

    }

    user.setRole(role);
    userService.save(user);

    return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
  }

  @PostMapping("/v1/signout")
  public ResponseEntity<MessageResponse> logoutUser() {
    ResponseCookie cookie = jwtUtils.getCleanJwtCookie();
    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString())
        .body(new MessageResponse("You've been signed out!"));
  }
}
