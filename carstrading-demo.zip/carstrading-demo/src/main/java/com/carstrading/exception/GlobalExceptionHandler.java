package com.carstrading.exception;

import com.carstrading.models.payload.response.MessageResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @Value(value = "${data.exception.message1}")
    private String message1;
    @Value(value = "${data.exception.message2}")
    private String message2;
    @Value(value = "${data.exception.message3}")
    private String message3;
    @Value(value = "${data.exception.message4}")
    private String message4;
    @Value(value = "${data.exception.message5}")
    private String message5;

    @ExceptionHandler(value = CarNotFoundException.class)
    public ResponseEntity carNotFoundException(CarNotFoundException carNotFoundException) {
        return new ResponseEntity<MessageResponse>(new MessageResponse(message1), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = RoleNotFoundException.class)
    public ResponseEntity roleNotFoundException(RoleNotFoundException roleNotFoundException) {
        return new ResponseEntity<MessageResponse>(new MessageResponse(message2), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = AccessDeniedException.class)
    public ResponseEntity accessDeniedException(Exception exception) {
        return new ResponseEntity<MessageResponse>(new MessageResponse(message3), HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity badRequestException(Exception exception) {
        return new ResponseEntity<MessageResponse>(new MessageResponse(message4), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity internalServiceErrorException(Exception exception) {
        return new ResponseEntity<MessageResponse>(new MessageResponse(message5), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
