

## START
```shell
mvn spring-boot:run
```

### Create admin account
- run below curl command
```shell
curl --location --request POST 'http://localhost:8085/api/auth/v1/signup' \
--header 'Content-Type: application/json' \
--header 'Cookie: Auth=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0YW8wMSIsIlJvbGVzIjpbIlJPTEVfQURNSU4iXSwiZXhwIjoxNjQ3MzYyNDQzLCJpYXQiOjE2NDcyNzYwNDN9.dJOgRXGC8pRua0xELx2ui7kBJSLw9siAngRCJyPiHpcOxCRnsku0lYfjXdQSbDlWQYsApOGeYqWlZnbmGOu64g; JSESSIONID=DC7217854F441B2AE5E092DB8631B6CD' \
--data-raw '{
    "username": "test01",
    "email": "test01@gmail.com",
    "password": "123456",
    "role": "admin"
}'
```
or 
- run postman test case /signup with payload
```json
{
    "username": "test01",
    "email": "test01@gmail.com",
    "password": "123456",
    "role": "admin"
}
```

### Access swagger with username/password
- http://localhost:8085/swagger-ui/index.html
- username: test01 
- password: 123456

### Access h2 database
- http://localhost:8085/h2-console
- url: jdbc:h2:mem:carstrading


## TEST
### Swagger
1. register an **admin** user
```json
POST: /api/auth/v1/signup
```
```json
{
  "username": "admin01",
  "email": "admin01@gmail.com",
  "role": "admin",
  "password": "123456"
}
```
2. signin **admin** account
```json
POST: /api/auth/v1/signin
```
```json
{
  "username": "test05",
  "password": "123456"
}
```
3. add cars
```json
POST: /api/cars/v1
```
```json
{
  "make": "Audi",
  "model": "v4"
}
```
4. delete cars
```json
DELETE: /api/cars/v1/{id}
```

5. register an **buyer** user 
```json
POST: /api/auth/v1/signup
```
```json
{
  "username": "buyer01",
  "email": "buyer01@gmail.com",
  "role": "buyer",
  "password": "123456"
}
```

6. signin **buyer** account
```json
POST: /api/auth/v1/signin
```
```json
{
  "username": "buyer01",
  "password": "123456"
}
```

7. get cars
```json
GET: /api/cars/v1
```

8. buy car
```json
PUT: /api/cars/v1/{id}
```

### Test cases and Exception
- scenario 1: Buyer not allowed to add cars
- scenario 2: Buyer not allowed to delete cars
- scenario 3: Cars have already been traded cannot be traded again
- scenario 4: Buyer only able to view the cars not traded yet
- scenario 5: Requests without valid Cookie are bad requests


### TODO: Unit test
- Unit test not completed due to tight time